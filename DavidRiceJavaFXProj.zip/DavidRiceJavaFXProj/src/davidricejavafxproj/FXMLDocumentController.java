/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package davidricejavafxproj;

import com.google.gson.Gson;
import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

/**
 *
 * @author csstudent
 */
public class FXMLDocumentController implements Initializable {
    private DataPoint[] data;
    @FXML
    private BarChart chart;
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String s = "http://apps.who.int/gho/athena/data/GHO/WHS4_544.json?profile=simple&filter=YEAR:1980";
        URL myurl = null;
        try {
            myurl = new URL(s);
        } catch (Exception e) {
            System.out.println("Improper URL " + s);
            System.exit(-1);
        }
     
        // read from the URL
        Scanner scan = null;
        try {
            scan = new Scanner(myurl.openStream());
        } catch (Exception e) {
            System.out.println("Could not connect to " + s);
            System.exit(-1);
        }
        
        String str = new String();
        while (scan.hasNext()) {
            str += scan.nextLine() + "\n";
        }
        scan.close();

        Gson gson = new Gson();
        PolioDataSet d = gson.fromJson(str, PolioDataSet.class);
        
        XYChart.Series<String, Number> Immunization = new XYChart.Series();
        Immunization.setName("Percent Immunization");
        Object[] data = d.keySet().toArray();
        Arrays.sort(data);
        for (Object dim : data) {
            Immunization.getData().add(new XYChart.Data(dim.toString(), Immunization.get(dim)));
        }
    }  
}
    
    

