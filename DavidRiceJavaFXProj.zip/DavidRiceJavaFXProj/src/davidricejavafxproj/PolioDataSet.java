/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package davidricejavafxproj;

/**
 *
 * @author csstudent
 */
class PolioDataSet {
    public DataPoint[] fact;
    
    @Override
    public String toString(){
        String output = "";
        for(DataPoint d : fact){
            output += d.toString();
            output += "\n";
        }
        return output;
    }
}
