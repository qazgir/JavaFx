/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package davidricejavafxproj;

/**
 *
 * @author csstudent
 */
class PolioDataPointInfo {
    private String COUNTRY;
    private int YEAR;
    public PolioDataPointInfo(){}
    public String getCountry(){
        return COUNTRY;
    }
    public int getYear(){
        return YEAR;
    }
}
